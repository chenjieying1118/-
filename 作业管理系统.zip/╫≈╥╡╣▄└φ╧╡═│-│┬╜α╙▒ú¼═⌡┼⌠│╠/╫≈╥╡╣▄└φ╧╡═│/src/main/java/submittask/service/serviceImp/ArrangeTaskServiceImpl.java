package submittask.service.serviceImp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import submittask.dao.StudentDao;
import submittask.dao.TTeacherDao;
import submittask.dao.TeacherCourseDao;
import submittask.pojo.TTeacher;
import submittask.service.ArrangeTaskService;

import java.io.File;
import java.util.List;

/**
 * Created by oupengcheng on 16/6/15.
 */
@Service("ArrangeTaskService")
public class ArrangeTaskServiceImpl implements ArrangeTaskService{

    @Autowired
    TeacherCourseDao teacherCoursedao;

    @Override
    public List<String> getTeacherAllCourse(String TeacherId){

        return teacherCoursedao.getTeacherAllCourse(TeacherId);
    }

    @Override
    public Integer getTeacherAllCourseNumber(String TeacherId,String CourseName) {

        return teacherCoursedao.getTeacherCourseNumber(TeacherId,CourseName);
    }

    @Override
    public void updataTaskWorkN(String TeacherId, String CourseName, String WorkN) {

        teacherCoursedao.updataTeacherWorkN(TeacherId,CourseName,WorkN);
    }

    @Override
    public boolean createNewDir(String DirName) {

        File Dir = new File("/Users/oupengcheng/Documents/"+DirName);

        System.out.print(DirName);
        if (Dir.mkdirs()) {
            System.out.println("创建目录" + DirName + "成功！");
            return true;
        } else {
            System.out.println("创建目录" + DirName + "失败！");
            return false;
        }

    }
}
