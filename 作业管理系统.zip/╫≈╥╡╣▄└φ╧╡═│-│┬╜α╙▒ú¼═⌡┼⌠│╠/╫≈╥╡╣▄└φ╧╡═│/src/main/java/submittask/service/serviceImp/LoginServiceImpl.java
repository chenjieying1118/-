package submittask.service.serviceImp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import submittask.dao.StudentDao;
import submittask.dao.TTeacherDao;

import submittask.service.LoginService;

/**
 * Created by oupengcheng on 16/6/8.
 */
@Service("LoginService")
public class LoginServiceImpl implements LoginService {

    @Autowired
    private TTeacherDao teacherDao;

    @Autowired
    private StudentDao studentDao;

    @Override
    public String checkLogin(String userId,String userPwd){

        if(!teacherDao.getTeacher(userId, userPwd).equals(null))
           return "teacher";
        else if(!studentDao.getStudent(userId, userPwd).equals(null))
            return"student";
        else
        return  null;
    }
}
