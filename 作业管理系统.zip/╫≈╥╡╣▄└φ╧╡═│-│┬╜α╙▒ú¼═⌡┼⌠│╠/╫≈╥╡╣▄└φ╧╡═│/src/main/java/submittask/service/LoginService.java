package submittask.service;

/**
 * Created by oupengcheng on 16/6/7.
 */
public interface LoginService {

    public String checkLogin(String teacherid,String passwords);

}
