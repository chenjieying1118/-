package submittask.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.IOException;


/**
 * Created by oupengcheng on 16/6/15.
 */

public interface OrganizeTaskService {

    /**
     * 文件夹: 老师帐号_课程_次数_上交截止日期.
     * 根据上传的文件名字 名字 去WEB—INF下相应文件查询找到(做一个文件搜索)所有的学生的名字放在list里面
     * 然后在数据库里面做一个匹配,匹配到的人标记为已经提交.
     */


    /**
     *
     * 文件下载
     * @param name
     * @param path
     * @return
     * @throws IOException
     */
    public ResponseEntity<byte[]> download(String name, String path) throws IOException;



}
