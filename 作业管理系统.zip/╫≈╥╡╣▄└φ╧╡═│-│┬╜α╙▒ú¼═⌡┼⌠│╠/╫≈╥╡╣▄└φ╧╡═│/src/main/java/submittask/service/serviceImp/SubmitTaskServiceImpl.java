package submittask.service.serviceImp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import submittask.dao.StudentCourseDao;
import submittask.service.SubmitTaskService;

import java.util.List;

/**
 * Created by oupengcheng on 16/6/26.
 */
@Service("SubmitTaskService")
public class SubmitTaskServiceImpl implements SubmitTaskService {

    @Autowired
    StudentCourseDao studentCourseDao;

    public Integer getStudentCourseNumber(String StudentId, String CourseName){

        return studentCourseDao.getStudentCourseNumber(StudentId,CourseName);
    }

    public List<String> getStudentAllCourse(String StudentId){

        return studentCourseDao.getStudentAllCourse(StudentId);
    }


}
