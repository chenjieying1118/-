package submittask.service;


import java.util.List;

/**
 * Created by oupengcheng on 16/6/15.
 */
public interface ArrangeTaskService {

    public Integer getTeacherAllCourseNumber(String TeacherId, String CourseName);

    public List<String> getTeacherAllCourse(String TeacherId);

    public void  updataTaskWorkN(String TeacherId,String CourseName,String WorkN);

    public boolean createNewDir(String DirName);

}
