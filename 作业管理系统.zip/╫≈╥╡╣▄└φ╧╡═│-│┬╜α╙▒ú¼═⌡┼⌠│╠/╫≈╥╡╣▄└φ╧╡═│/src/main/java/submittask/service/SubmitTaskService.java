package submittask.service;

import java.util.List;

/**
 * Created by oupengcheng on 16/6/26.
 */
public interface SubmitTaskService {

    public Integer getStudentCourseNumber(String StudentId, String CourseName);

    public List<String> getStudentAllCourse(String StudentId);


}
