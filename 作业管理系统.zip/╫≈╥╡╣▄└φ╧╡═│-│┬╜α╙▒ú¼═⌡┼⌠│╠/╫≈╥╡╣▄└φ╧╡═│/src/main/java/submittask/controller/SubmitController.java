package submittask.controller;

import com.alibaba.fastjson.JSON;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import submittask.service.SubmitTaskService;

import javax.annotation.Resource;

/**
 * Created by oupengcheng on 16/6/26.
 */
@Controller
@RequestMapping(value="/submittask")
public class SubmitController {

    @Resource
    SubmitTaskService submitTaskService;

    @ResponseBody
    @RequestMapping(value="/confirm")
    public String showTask(@RequestParam("studentId") String StudentId)
    {
        /**
         * get the programs of the teacher
         */
        return JSON.toJSONString(submitTaskService.getStudentAllCourse(StudentId));

    }

    @RequestMapping(value="/course")
    public String showTaskNumber(@RequestParam("teacherId") String StudentId,@RequestParam("courseName") String CouseName)
    {
        /**
         * get the number of student's workN
         */
        return JSON.toJSONString(submitTaskService.getStudentCourseNumber(StudentId,CouseName));
    }




}
