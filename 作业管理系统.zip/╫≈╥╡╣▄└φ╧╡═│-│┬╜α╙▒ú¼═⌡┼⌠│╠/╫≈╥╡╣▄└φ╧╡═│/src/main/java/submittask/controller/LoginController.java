package submittask.controller;

import com.alibaba.fastjson.JSON;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import submittask.service.LoginService;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;



/**
 * Created by oupengcheng on 16/6/8.
 */
@Controller
@RequestMapping(value = "/log")
public class LoginController {
    @Resource
    private LoginService loginService;

    @ResponseBody
    @RequestMapping(value="/in")
    public String checkLogin(@RequestParam("userId") String userId,@RequestParam("userPwd")String userPwd) {
        Map<String, Object> result = new HashMap<String, Object>();
       System.out.print("enter control11");
        String userdegree = loginService.checkLogin(userId, userPwd);
        if (!userdegree.equals(null))
        {
            result.put("status","success");
            result.put("userDegree",userdegree);
//            System.out.print("success");
        } else {
            result.put("status", "fail");
//            System.out.print("fail");
        }
       return JSON.toJSONString(result);

    }


}
