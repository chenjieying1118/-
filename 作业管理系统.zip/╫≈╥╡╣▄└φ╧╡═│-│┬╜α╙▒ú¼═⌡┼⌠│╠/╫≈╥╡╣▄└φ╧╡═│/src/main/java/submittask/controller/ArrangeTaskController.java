package submittask.controller;

import com.alibaba.fastjson.JSON;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import submittask.service.ArrangeTaskService;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by oupengcheng on 16/6/15.
 */
@Controller
@RequestMapping(value="/arrangetask")
public class ArrangeTaskController {
    @Resource
    ArrangeTaskService arrangeTaskService;

    @ResponseBody
    @RequestMapping(value="/confirm")
    public String showTask(@RequestParam("teacherId") String TeacherId)
    {
        /**
         * get the programs of the teacher
         */
        return JSON.toJSONString(arrangeTaskService.getTeacherAllCourse(TeacherId));

    }

    @ResponseBody
    @RequestMapping(value="/course")
    public String arrangeTask(@RequestParam("teacherId") String TeacherId,@RequestParam("courseName") String CouseName)
    {
        /**
         * get the number of teacher's workN
         */
        return JSON.toJSONString(arrangeTaskService.getTeacherAllCourseNumber(TeacherId,CouseName));
    }


    @ResponseBody
    @RequestMapping(value="/submit")
    public void collectTask(@RequestParam("teacherId") String TeacherId,@RequestParam("courseName") String CouseName,@RequestParam("workN") String WorkN )
    {
        /**
         *  将目前的课程作业更新到数据库中
         */
        arrangeTaskService.updataTaskWorkN(TeacherId,CouseName,WorkN);
    }

    @ResponseBody
    @RequestMapping(value="/upload",method = RequestMethod.POST)
    public String createDir(@RequestParam("folderInfo") String FolderInfo)
    {
        System.out.print("enter control");
        Map<String, Object> result = new HashMap<String, Object>();
        System.out.print(FolderInfo);
        if(arrangeTaskService.createNewDir(FolderInfo)){

            result.put("state","yes");
            result.put("url","/Users/oupengcheng/Documents/"+FolderInfo);
        }
        else
            result.put("state","no");

        return JSON.toJSONString(result);
    }
}
