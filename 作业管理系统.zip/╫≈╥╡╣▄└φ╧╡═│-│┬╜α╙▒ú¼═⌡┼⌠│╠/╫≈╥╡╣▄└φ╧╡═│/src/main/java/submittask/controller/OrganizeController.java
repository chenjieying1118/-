package submittask.controller;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import submittask.service.OrganizeTaskService;

import javax.annotation.Resource;
import java.io.IOException;

/**
 * Created by oupengcheng on 16/6/15.
 */
@Controller

public class OrganizeController {

    @Resource
    OrganizeTaskService organizeTaskService;
    @ResponseBody
    @RequestMapping(value="/downLoad")
public void downLoadFile(@Param("filename") String FileName, @Param("submitdata") String SubmitData) throws IOException {
    /**
     *  从前端获取学生的名字,在WEB-INF路径下相应的日期文件夹里面
     */
        organizeTaskService.download(FileName,SubmitData);
}

}
