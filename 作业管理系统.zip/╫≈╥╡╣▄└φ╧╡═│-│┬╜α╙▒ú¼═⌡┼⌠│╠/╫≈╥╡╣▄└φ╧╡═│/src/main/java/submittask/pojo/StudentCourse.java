package submittask.pojo;

/**
 * Created by oupengcheng on 16/6/23.
 */
public class StudentCourse {
    String teacherId;
    String courseId;
    String workN;

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    public String getWorkN() {
        return workN;
    }

    public void setWorkN(String workN) {
        this.workN = workN;
    }

}
