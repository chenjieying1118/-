package submittask.pojo;

import submittask.dao.TeacherCourseDao;

/**
 * Created by oupengcheng on 16/6/23.
 */
public class TeacherCourse {

    String teacherId;
    String courseId;
    String lastestdeadline;
    String workN;

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getLastestdeadline() {
        return lastestdeadline;
    }

    public void setLastestdeadline(String lastestdeadline) {
        this.lastestdeadline = lastestdeadline;
    }

    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    public String getWorkN() {
        return workN;
    }

    public void setWorkN(String workN) {
        this.workN = workN;
    }
}
