package submittask.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import submittask.pojo.TTeacher;

import java.util.List;

@Repository
public interface TTeacherDao {
    /**
     *  根据老师的id获取所有信息
     */
    public TTeacher getTeacherAllInf(String TeacherId);

    /**
     * 根据老师用户名密码获取是否在数据库中存在
     */
    public String getTeacher(@Param("t_teacherid") String TeacherId, @Param("t_passwords")String TeacherPasswords);

}