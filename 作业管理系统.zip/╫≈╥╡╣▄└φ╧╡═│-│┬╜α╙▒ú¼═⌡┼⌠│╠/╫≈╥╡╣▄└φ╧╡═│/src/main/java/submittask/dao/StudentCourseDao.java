package submittask.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by oupengcheng on 16/6/23.
 */
@Repository
public interface StudentCourseDao {
    /**
     * 根据学生id获取他学的的所有的课
     */
    public List<String> getStudentAllCourse(@Param("s_studentid") String StudentId);
    /**
     * get number
     */
    public Integer getStudentCourseNumber(@Param("s_studentid") String StudentId,@Param("s_coursename") String CourseName);
}
