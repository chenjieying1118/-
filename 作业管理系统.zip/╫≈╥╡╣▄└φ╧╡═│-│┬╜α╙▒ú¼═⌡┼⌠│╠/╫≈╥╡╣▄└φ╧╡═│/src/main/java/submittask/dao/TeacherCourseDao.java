package submittask.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by oupengcheng on 16/6/23.
 */
@Repository
public interface TeacherCourseDao {

    /**
     * 根据老师id获取她教的所有的课
     */
    public List<String> getTeacherAllCourse(@Param("t_teacherid") String TeacherId);
    /**
     *  根据老师id和某门课获取这门课的作业数量
     */
    public Integer getTeacherCourseNumber(@Param("t_teacherid") String TeacherId, @Param("t_coursename")String CourseName);
    /**
     *  更新作业workn
     */
    public void updataTeacherWorkN(@Param("t_teacherid")String TeacherId,@Param("t_coursename")String CourseName,@Param("t_workN")String WorkN);

}
