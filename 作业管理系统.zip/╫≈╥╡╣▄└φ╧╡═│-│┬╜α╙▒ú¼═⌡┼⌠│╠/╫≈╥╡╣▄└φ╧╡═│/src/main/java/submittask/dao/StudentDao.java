package submittask.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import submittask.pojo.TStudent;

import java.util.List;

/**
 * Created by oupengcheng on 16/6/15.
 */
@Repository
public interface StudentDao {
    /**
     *  根据学生的id获取所有信息
     */
    public TStudent getStudentAllInf(String StudentId);

    /**
     * 根据学生用户名密码获取是否在数据库中存在
     */
    public String getStudent(@Param("s_studentid") String StudentId, @Param("s_passwords")String StudentPasswords);
}
