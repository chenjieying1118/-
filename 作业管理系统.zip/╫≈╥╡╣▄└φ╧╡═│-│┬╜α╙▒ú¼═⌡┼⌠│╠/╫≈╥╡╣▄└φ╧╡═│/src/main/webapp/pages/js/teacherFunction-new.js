var userInfo = window.location.href.split('?')[1];
var userDegree = userInfo.split('&')[0].split('=')[1];
var userId = userInfo.split('&')[1].split('=')[1];

var curCourseName = '';
var curWorkN = '';
var curReadMePath = '';
var curStuName = ''; //当前被批改的学生姓名

function init() {
	var params = {
		userDegree: userDegree,
		userId: userId
	}
	/*
	 * 前端测试用
	 */
	//	$('#course-list').children().detach();
	//	var array = [];
	//	array.push(
	//		'<li><a data-toggle="modal" href="#set-workN" class="btn"><p>' + 'nihao' + '</p></a></li>'+
	//		'<li><a data-toggle="modal" href="#set-workN" class="btn"><p>' + 'java' + '</p></a></li>'
	//
	//	);
	//	$('#course-list').append(array.join(''));

	$.ajax({
		type: "POST",
		url: "#",
		async: true,
		data: params,
		dataType: 'json',
		success: function(data) {
			$('#course-list').children().detach();
			var array = [];
			$.each(data, function(i, e) {
				array.push(
					'<li><a data-toggle="modal" href="#set-workN" class="btn"><p>' + e + '</p></a></li>'
				);

			});
			$('#course-list').append(array.join(''));
		},
		error: function() {
			alert('获得所有课程后台错误');
		}
	});
}

function basicEvent() {

	//进入改密码界面
	$('#changPwd').on('click',function(){
		var userInfo = window.location.href.split('?')[1];
		window.location.href='changePwd.html?userDegree=teacher&userId='+userId;
	});
	//获得选择的课程名
	$('.btn-course').on('click', function() {
		curCourseName = $(this).children('p').text();
	});
	//获得选定的workN
	$('#set-workN-choose-ok').on('click', function() {
		curWorkN = $("input[type='radio'][name='workN']:checked").val();
	});
	//获得需要批改学生的姓名
	$('.correct').on('click', function() {
		curStuName = $(this).parent().children('span').text();
	});
	//获得批改信息
	$('#correct-ok').on('click', function() {
		var checkText = $('#check-text').val();
		var params = {
			userId: userId,
			curCourseName: curCourseName,
			curWorkN: curWorkN,
			curStuName: curStuName,
			checkText: checkText
		}
		$.ajax({
			type: "POST",
			async: true,
			url: '#',
			data: params,
			dataType: 'json',
			success: function(data) {
				if (data.state == 'yes') {
					alert('批注上传成功')

				} else {
					alert('批注上传失败')
				}
			},
			error: function() {
				alert('向后台请求数据失败,无法上传批注');
			}
		});

	});
	//检查作业时获得workN
	$('#check-workN-choose-ok').on('click', function() {
		curWorkN = $("input[type='radio'][name='workN']:checked").val();
		alert(curWorkN);
		var params = {
			userDegree: userDegree,
			userId: userId,
			curCouserName: curCourseName,
			curWorkN: curWorkN
		}
		/*
		 * 前端调试用
		 $('#stuForm-container').children().detach();
		 var array = [];
		 array.push('<div class="choose-stu">&radic;王鹏程'+
		 '<button class="btn btn-default correct" data-dismiss="modal" data-toggle="modal" data-target="#correct-dialog">批改</button>'+
		 '<button class="btn btn-default download-homework" data-dismiss="modal" data-toggle="modal" data-target="#download-dialog">下载</button>'+
		 '</div>')
		 $('#stuForm-container').append(array.join(''));
		 */

		//获得学生交作业名单
		$.ajax({
			type: "POST",
			url: "#",
			async: true,
			data: params,
			dataType: "json",
			success: function(data) {
				$('#stuForm-container').children().detach();
				var array = [];
				$.each(data, function(i, e) {
					if (e.state == 'yes') {
						array.push(
							'<div class="choose-stu">',
							'&radic;' + e.name,
							'<button class="btn btn-default correct" data-dismiss="modal" data-toggle="modal" data-target="#correct-dialog">',
							'批改',
							'</button>',
							'<button class="btn btn-default download-homework" data-dismiss="modal" data-toggle="modal" data-target="#download-dialog">',
							'下载',
							'</button>',
							'</div>'
						);
					} else {
						array.push(
							'<div class="choose-stu">' + e.name,
							'<button class="btn btn-default correct" data-dismiss="modal" data-toggle="modal" data-target="#correct-dialog">',
							'批改</button>',
							'<button class="btn btn-default download-homework" data-dismiss="modal" data-toggle="modal" data-target="#download-dialog">',
							'下载</button></div>'
						);
					}
				});
				$('#stuForm-container').append(array.join(''));
			},
			error: function() {
				alert('后台错误');
			}
		});
	});
	//布置作业时获得deadline,并此时通知后台创建相应文件夹
	
	$('#set-deadline-ok').on('click', function() {
		var curDeadline = $('#deadline').val();
		alert(curDeadline);
		var folderInfo=userId+"_"+curCourseName+"_"+"workn"+"_"+curDeadline;
		var params = {
			folderInfo: folderInfo
		}
		//让后台创建相应文件夹，并把url传过来
		$.ajax({
			type: "POST",
			async: true,
			url: '/arrangetask/upload.html',
			data: params,
			dataType: 'json',
			success: function(data) {
				if (data.state == 'no') {
					alert('后台创建文件夹失败，无法上传')
					//					$(this).data-target = none;//如何获得某元素的data-target
				} else {
					$('.dropzone').action = data.url;
					alert(data.url);
				}
			},
			error: function() {
				alert('向后台请求数据失败，无法上传');
				//				$(this).data-target = "#";
			}
		});

	});

}
basicEvent();
init();