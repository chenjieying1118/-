alert('3');
var userInfo = window.location.href.split('?')[1];
var userDegree = userInfo.split('&')[0].split('=')[1];
var userId = userInfo.split('&')[1].split('=')[1];


function changePage() {
	$('#go').on('click', function() {
		alert(userDegree);
		
		if(userDegree=='student'){
			window.location.href='stuPage.html?userDegree=student&userId='+userId;
		}
		else if(userDegree=='teacher'){
			window.location.href='teacherPage.html?userDegree=teacher&userId='+userId;
		}
		else if(userDegree=='manager'){
			window.location.href='teacherPage.html?userDegree=manager&userId='+userId;
		}
	});

}
changePage()