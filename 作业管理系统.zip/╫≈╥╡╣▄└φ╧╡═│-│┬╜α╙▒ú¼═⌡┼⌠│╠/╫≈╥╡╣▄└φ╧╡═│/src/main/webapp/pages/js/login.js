function login() {
	$('#Login-new').on('click', function() {
		userId = $('#username').val();
		userPwd = $('#password').val();
		alert(userId);
		var params = {
			userId: userId,
			userPwd: userPwd
		};
//测试用


		$.ajax({
			type: "POST",
			url: "/log/in.html",
			async: true,
			data: params,
			dataType: 'json',

			success: function(data) {
				if (data.status == 'success') {
					if (data.userDegree == 'student') {
						window.location.href = 'stuPage.html?userDegree=student&userId=' + params.userId;
					} else if (data.userDegree == 'teacher') {
						window.location.href = 'teacherPage.html?userDegree=teacher&userId=' + params.userId;
					} else if (data.userDegree == 'manager') {
						window.location.href = 'managerPage.html?userDegree=manager&userId=' + params.userId;
					} else {
						alert('login failed' + resData.status);
					}
				}
			},
			error: function() {
				alert('后台错误');
			}
		});
	});

}
login()