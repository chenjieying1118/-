function changePwd() {
	var userInfo = window.location.href.split('?')[1];
	$('#back-to-homePage').on('click',function(){
		var userDegree = userInfo.split('&')[0].split('=')[1];
		if(userDegree=='teacher'){
			window.location.href='teacherPage.html?'+userInfo;
		}
		else if(userDegree=='student'){
			window.location.href='stuPage.html?'+userInfo;
		}
		else{
			window.location.href='managerPage.html?'+userInfo;
		}
	});
	$('#confirm').on('click', function() {
		oldPwd = $('#old-pwd').val();
		newPwd = $('#new-pwd').val();
		var params = {
			oldPwd: oldPwd,
			newPwd: newPwd
		};

		$.ajax({
			type: "POST",
			url: "#",
			async: true,
			data: params,
			dataType: 'json',

			success: function(data) {
				if (data.state == 'old-pwd wrong') {
					alert('您的旧密码输入有误,请重新输入')
				}
				else if(data.state == 'succe'){
					alert('修改成功啦')
				}
			},
			error: function() {
				alert('后台错误');
			}
		});
	});

}
changePwd()