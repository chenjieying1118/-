//global config
var config = {
    ENV: 'dev'  //toggle environment ('dev'||'pub')
};