
$('#menuTop').on('click', 'li' ,function(event) {
    var content = $(this).children('a').attr('href');
    $('.setHomework').removeClass('active');
    $('#menuTop li').removeClass('active');
    $(this).addClass('active');
    $('.container-all').children().css('display', 'none');
    $(content).css('display', 'block');
});
   
