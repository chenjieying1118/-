var userInfo = window.location.href.split('?')[1];
var userDegree = userInfo.split('&')[0].split('=')[1];
var userId = userInfo.split('&')[1].split('=')[1];

var curCourseName = '';
var curWorkN = '';

function init() {
	var params = {
		userDegree: userDegree,
		userId: userId
	}

	$.ajax({
		type: "POST",
		url: "#",
		async: true,
		data: params,
		dataType: 'json',
		success: function(data) {
			$('#course-list').children().detach();
			var array = [];
			$.each(data, function(i, e) {
				array.push(
					'<li><a data-toggle="modal" href="#set-workN" class="btn"><p>' + e + '</p></a></li>'
				);

			});
			$('#course-list').append(array.join(''));
		},
		error: function() {
			alert('学生界面获得所有课程后台错误');
		}
	});
}

function basicEvent() {
	//更改密码
	$('#changPwd').on('click', function() {
		var userInfo = window.location.href.split('?')[1];
		window.location.href = 'changePwd.html?userDegree=student&userId='+userId;
	});
	//获得当前选择的课程
	$('.btn-course').on('click', function() {
		curCourseName = $(this).children('p').text();
	});

	//上传作业时获得当前workN，并获得url
	$('#set-workN-choose-ok').on('click', function() {
		curWorkN = $("input[type='radio'][name='workN']:checked").val();
		var params = {
			userId: userId,
			curCourseName: curCourseName,
			curWorkN: curWorkN
		}

		//让后台创建相应文件夹，并把url传过来
		$.ajax({
			type: "POST",
			async: true,
			url: '#',
			data: params,
			dataType: 'json',
			success: function(data) {
				if (data.state == 'no') {
					alert('后台创建文件夹失败，无法上传');
				} else {
					$('.dropzone').action = data.url;
				}
			},
			error: function() {
				alert('向后台请求数据失败，无法上传');
				//				$(this).data-target = "#";
			}
		});

	});
	//选择文件夹后，下载已提交作业,后端查找是否有相应文件夹，还未测试
	$('#choose-downloadFile-ok').on('click', function() {
		var filePath = $('#filePath').val();
		alert(filePath);
		var params = {
			userId: userId,
			curCourseName: curCourseName,
			curWorkN: curWorkN
		}

		$.ajax({
			type: "POST",
			async: true,
			url: '#',
			data: params,
			dataType: 'json',
			success: function(data) {
				if (data.state == 'yes') {
					//写啥，不造啊，什么什么鬼href
				} else {
					alert('未找到相应文件')
				}
			},
			error: function() {
				alert('向后台请求数据失败');
			}
		});

	});
	//获得批改信息
	$('#get-correct-ok').on('click', function() {
		var params = {
			userId: userId,
			curCourseName: curCourseName,
			curWorkN: curWorkN
		}
		$.ajax({
			type: "POST",
			async: true,
			url: '#',
			data: params,
			dataType: 'json',
			success: function(data) {
				if (data.state == 'yes') {
					alert('获得批注成功!')
					$('#correct-text').text = data.text;
				} else {
					alert('获得批注失败')
				}
			},
			error: function() {
				alert('向后台请求数据失败,获得批注');
			}
		});

	});

	//查看已提交作业时获得workN
	$('#download-homework-ok').on('click', function() {
		curWorkN = $("input[type='radio'][name='workN']:checked").val();
	});
}
basicEvent();
init();